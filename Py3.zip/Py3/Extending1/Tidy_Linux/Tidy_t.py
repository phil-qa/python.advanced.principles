#!/usr/local/bin/python3

import Tidy

Tidy.TidyDir('.')
