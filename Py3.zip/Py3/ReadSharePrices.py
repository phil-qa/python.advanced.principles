#!/usr/local/bin/python3
# ReadSharePrices.py student version
# Python 3
# CBD 1st Feb.2011
import os.path
import sys
import getopt
from socket import *

if __name__ == '__main__':

    nPortID = 600;                # Hardcoded
    ServiceName = "garcon"

    #  TO DO: Create a connection based socket to receive share prices
    

    #  TO DO: Bind socket to address


    #  TO DO: Set maximum number of pending requests for connection
    
    
    print("\nWaiting for connection by share price program...")

    #  TO DO: Wait for share price program to connect to socket
    #         and obtain a new socket
    
        
    #  TO DO: Original socket is no longer required, so close it
   

    print("\n\nConnection received waiting for data...\n")
    
    while True:
        #  TO DO: Receive data from share price program

        
        #  TO DO: Display the received byte data


    #  TO DO: Close the connected socket





