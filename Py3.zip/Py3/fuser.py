#!/usr/local/bin/python3
import psutil
import sys
import os.path

if len(sys.argv) < 2:
    exit("Please supply a file name")

target = sys.argv[1]

# TODO: Insert your code here

