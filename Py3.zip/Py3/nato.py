#!/usr/local/bin/python3
# Python 3 version
import string

nato = ['zero','wun','two','tree','fower',
        'fife','six','seven','ait','niner',
        'alpha','bravo','charlie','delta','echo',
        'foxtrot','golf','hotel','india','juliet',
        'kilo','lima','mike','november','oscar','papa',
        'quebec','romeo','sierra','tango','uniform',
        'victor','whisky','xray','yankee','zulu']

# TODO: Construct your codes dictionary here
codes = {}

import pprint
pprint.pprint(codes)

txt = ' '
while txt:
    txt = input("Please enter a phrase:")
    # TODO: print each letter as a phonetic word
    # Don't forget to handle embedded spaces


        
