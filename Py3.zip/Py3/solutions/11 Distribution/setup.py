#!/usr/local/bin/python3
from distutils.core import setup

setup(
    name = "containers",
    py_modules = ['containers'],
    )
